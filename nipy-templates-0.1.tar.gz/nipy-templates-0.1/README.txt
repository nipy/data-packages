NIPY template data
------------------

This is a NIPY data package.

Please see the NIPY online documentation for details.

Please review the README file in the ``templates`` subdirectory.
